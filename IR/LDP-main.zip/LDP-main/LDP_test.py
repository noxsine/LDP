import numpy as np
import os
import argparse
from tqdm import tqdm
import torch.nn as nn
import torch
from basicsr.models.archs.backbone import LDP
import cv2
import utils
from natsort import natsorted
from glob import glob

parser = argparse.ArgumentParser(description='Dual Pixel Defocus Deblurring using Restormer')

parser.add_argument('--input_dir', default='./Dataset', type=str, help='Directory of validation images')
parser.add_argument('--result_dir', default='./Results', type=str, help='Directory for results')
parser.add_argument('--weights', default=r'./pretrained_models\model.pth', type=str, help='Path to weights')
parser.add_argument('--save_images', action='store_true', help='Save denoised images in result directory')

args = parser.parse_args()
model_restoration = LDP()
checkpoint = torch.load(args.weights)
model_restoration.load_state_dict(checkpoint['params'])
print("Testing")
model_restoration.cuda()
model_restoration = nn.DataParallel(model_restoration)
model_restoration.eval()

result_dir = args.result_dir
if args.save_images:
    os.makedirs(result_dir, exist_ok=True)

filesL = natsorted(glob(os.path.join(args.input_dir, 'inputL', '*.png')))
filesR = natsorted(glob(os.path.join(args.input_dir, 'inputR', '*.png')))
filesC = natsorted(glob(os.path.join(args.input_dir, 'target', '*.png')))
filesM = natsorted(glob(os.path.join(args.input_dir, 'blurmap', '*.png')))

psnr, mae, ssim, pips = [], [], [], []
with torch.no_grad():
    for fileL, fileR, fileC, fileM in tqdm(zip(filesL, filesR, filesC,filesM ), total=len(filesC)):

        imgL = np.float32(utils.load_img16(fileL))/255.
        imgR = np.float32(utils.load_img16(fileR))/255.
        imgC = np.float32(utils.load_img16(fileC))/255.
        imgM = np.float32(utils.load_img16(fileM))/255.

        t_C = torch.from_numpy(imgC).unsqueeze(0).permute(0,3,1,2).cuda()
        t_L = torch.from_numpy(imgL).unsqueeze(0).permute(0,3,1,2)
        t_R = torch.from_numpy(imgR).unsqueeze(0).permute(0,3,1,2)
        t_M = torch.from_numpy(imgM).unsqueeze(0).permute(0,3,1,2)
        input_ = torch.cat([t_L, t_R,t_M], 1).cuda()

        restored = model_restoration(input_)
        restored = torch.clamp(restored,0,1)
        restored = restored.cpu().detach().permute(0, 2, 3, 1).squeeze(0).numpy()

        save_file = os.path.join(result_dir, os.path.split(fileC)[-1])
        restored = np.uint8((restored*255).round())
        utils.save_img(save_file, restored)
print("Finished")

